package com.example.testfragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;


public class Fragment1 extends Fragment{

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	}
	public static Fragment1 newInstance(int index) { 
		Fragment1 details = new Fragment1();
		Bundle args = new Bundle();
		args.putInt("index", index);
		details.setArguments(args);
		return details;
	}
	public int getShownIndex() {
		return getArguments().getInt("index", 0);
	}
	/**
	 * Ƕ�벼���ļ�������ListView��������������������
	 */
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		View view=inflater.inflate(R.layout.fragment1, container,true);
		ListView lv_contact=(ListView)view.findViewById(R.id.lv_contact);
		ArrayAdapter<String> lv_adapter=new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1,MainActivity.contact);
		lv_contact.setAdapter(lv_adapter);
		lv_contact.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				MainActivity.conindex=arg2;
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		return view;
	}

}
