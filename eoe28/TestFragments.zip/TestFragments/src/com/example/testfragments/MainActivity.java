package com.example.testfragments;


import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends FragmentActivity {
	public static final String[] contact= { "����", "����", "����", "����","����", "κ��", "����" };
	public static final String[] phnumber={"5554","5556","5554","5556","5554","5556","5554"};
	private static final String SMS_SEND="com.SMSDemo.SMS.send";
	private static final String SMS_RECEIVE="android.provider.Telephony.SMS_RECEIVED";
	static int conindex=0;
	public static String MY_NAME="me";
	public static Context context;
	private SMSReceiver smsReceiver;
	private SMSReceiver receiverReceiver;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		context=MainActivity.this;
		smsReceiver=new SMSReceiver();
		IntentFilter sendFilter=new IntentFilter(SMS_SEND);
		registerReceiver(smsReceiver,sendFilter);
		receiverReceiver=new SMSReceiver();
		IntentFilter receiveFilter=new IntentFilter(SMS_RECEIVE);
		registerReceiver(receiverReceiver,receiveFilter);
		sendListener(R.id.btn_send,R.id.et_context1,R.id.et_context2);
	}
	/**
	 * ����Fragment�з��Ͱ�ť
	 * @param buttonId��ťID
	 * @param etId1����EditText
	 * @param etId2��������EditText
	 */
	public void sendListener(int buttonId,int etId1,int etId2){
		Button btn_send=(Button)findViewById(buttonId);
		final EditText et_text=(EditText)findViewById(etId2);
		final EditText et_chat=(EditText)findViewById(etId1);
		btn_send.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if("".equals(et_text.getText().toString().trim())){
					Toast.makeText(MainActivity.context, "û���������ݣ����������ݺ���", Toast.LENGTH_SHORT).show();				
				}else{
					StringBuffer sb_chat=new StringBuffer();
					String text=et_text.getText().toString();
					sb_chat.append(et_chat.getText()+"\r\n"+MY_NAME+":"+text);
					et_chat.setText(sb_chat);
					sendSMS(text);
				}				
			}
		});		
	}
	/**
	 * ��ʾ����
	 * @param etchatId�������EditText
	 * @param text��������
	 */
	public void getSMS(int etchatId,String text){
		EditText et_chat=(EditText)findViewById(etchatId);
		StringBuffer sb_chat=new StringBuffer();
		sb_chat.append(et_chat.getText()+"\r\n"+text);
		et_chat.setText(sb_chat);
	}
	/**
	 * ���Ͷ���
	 * @param text
	 */
	public static void sendSMS(String text){
		SmsManager smsManager=SmsManager.getDefault();
		Intent sIntent=new Intent(SMS_SEND);
		PendingIntent sentIntent=PendingIntent.getBroadcast(context, 0, sIntent, 0);
		smsManager.sendTextMessage(phnumber[conindex], null, text, sentIntent, null);
	}
	/**
	 * ���ն��źͷ���״̬��Ϣ
	 * @author Administrator
	 *
	 */
	public class SMSReceiver extends BroadcastReceiver{

		@Override
		public void onReceive(Context arg0, Intent arg1) {
			// TODO Auto-generated method stub
			String action=arg1.getAction();
			int resultCode=getResultCode();
			if(action.equals(SMS_SEND)){
				switch(resultCode){
				case Activity.RESULT_OK://���Ͷ��ųɹ�
					Toast.makeText(context, "SMS is success", Toast.LENGTH_SHORT).show();
					break;
				case SmsManager.RESULT_ERROR_GENERIC_FAILURE://���Ͷ���ʧ��
					Toast.makeText(context, "SMS is failure", Toast.LENGTH_SHORT).show();
					break;
				case SmsManager.RESULT_ERROR_NO_SERVICE://�޷���
					Toast.makeText(context, "No service!", Toast.LENGTH_SHORT).show();
					break;
				case SmsManager.RESULT_ERROR_NULL_PDU://��������
					Toast.makeText(context, "No such number!", Toast.LENGTH_SHORT).show();
					break;
				case SmsManager.RESULT_ERROR_RADIO_OFF://�ֻ��ػ�
					Toast.makeText(context, "The number is shut down!", Toast.LENGTH_SHORT).show();
					break;
				}
			}else if(action.equals(SMS_RECEIVE)){
				Bundle bundle=arg1.getExtras();
				if(bundle!=null){
					Object[] object=(Object[])bundle.get("pdus");
					SmsMessage[] messages=new SmsMessage[object.length];
					for(int i=0;i<object.length;i++){
						messages[i]=SmsMessage.createFromPdu((byte[])object[i]);
					}
					SmsMessage message=messages[0];
					Toast.makeText(context, message.getMessageBody().toString(), Toast.LENGTH_SHORT).show();
					String text=message.getMessageBody().toString();
					getSMS(R.id.et_context1,text);					
				}
			}
		}
		
	}
}
