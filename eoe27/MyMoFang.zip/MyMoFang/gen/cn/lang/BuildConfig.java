/** Automatically generated file. DO NOT MODIFY */
package cn.lang;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}