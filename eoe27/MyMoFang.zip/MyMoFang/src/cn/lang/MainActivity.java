package cn.lang;

import android.os.Bundle;
import android.util.DisplayMetrics;
import android.app.Activity;

public class MainActivity extends Activity {
	private MyGLSurfaceView mysurfaceview;
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        DisplayMetrics  dm = new DisplayMetrics();   
        //ȡ�ô�������   
        getWindowManager().getDefaultDisplay().getMetrics(dm);         
        //���ڵĿ���   
        int screenWidth = dm.widthPixels;            
        //���ڸ߶�   
        int screenHeight = dm.heightPixels;
        float ratex = screenWidth/(float)320;
        float ratey = screenHeight/(float)480;
		mysurfaceview = new MyGLSurfaceView(this,ratex,ratey);
		setContentView(mysurfaceview);
	}
	protected void onPause(){
		super.onPause();
		mysurfaceview.onPause();
	}
	protected void onResum(){
		super.onResume();
		mysurfaceview.onResume();
	}
}
