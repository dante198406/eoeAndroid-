package com.respider.demos;

import javax.microedition.khronos.opengles.GL10;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import rajawali.lights.DirectionalLight;
import rajawali.materials.DiffuseMaterial;
import rajawali.primitives.Sphere;
import rajawali.renderer.RajawaliRenderer;

public class Renderer extends RajawaliRenderer {
	Sphere mSphere;

	public Renderer(Context context) {
		super(context);
		setFrameRate(30);
	}

	@Override
	public void onSurfaceChanged(GL10 gl, int width, int height) {
		DirectionalLight mLight = new DirectionalLight(0.1f, 0.2f, 1.0f);
		mLight.setPower(1.5f);
		Bitmap bg = BitmapFactory.decodeResource(mContext.getResources(),
				R.drawable.earthtruecolor_nasa_big);
		mSphere = new Sphere(1, 12, 12);
		DiffuseMaterial material = new DiffuseMaterial();
		mSphere.setMaterial(material);
		mSphere.addLight(mLight);
		mSphere.addTexture(mTextureManager.addTexture(bg));
		addChild(mSphere);
		mCamera.setZ(-4.2f);
		super.onSurfaceChanged(gl, width, height);
	}

	@Override
	public void onDrawFrame(GL10 glUnused) {
		super.onDrawFrame(glUnused);
		mSphere.setRotY(mSphere.getRotY() + 1);
	}
}
