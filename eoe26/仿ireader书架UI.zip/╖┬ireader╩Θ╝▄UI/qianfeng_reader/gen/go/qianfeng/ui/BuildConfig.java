/** Automatically generated file. DO NOT MODIFY */
package go.qianfeng.ui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}