/************************************************************************
*	项目名字		:圆柱状图形表 
*   子项目名字 		:矩形实体类
*   功能的名字            :矩形实体类属性
　*  功能介绍  		:对矩形实体类属性设置和增加绘画方法
　* 	类名			：Chart
　* 最后注释者   		：膏药
　* 时间			：2012.10.1
************************************************************************/

package cn.knight.barchart;

import android.graphics.Canvas;
import android.graphics.Paint;
//矩形实体类
public class Chart {

	private final int w = 20;
	private int h;
	private final int total_y = 300;
	private int x;

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getH() {
		return h;
	}

	public void setH(int h) {
		this.h = h;
	}

	// 画一个(150, 10, 200, 60)表示一个左上顶点坐标为(150,20),右下顶点为(200,60)的矩形
	// 下面是同理
	public void drawSelf(Canvas canvas, Paint paint) {
		canvas.drawRect(x, total_y - h, w + x, total_y - 1, paint);
	}

}
